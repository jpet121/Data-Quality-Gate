# Corrected validator release and evidence

**Technical verification passed. Release decision: NOT APPROVED pending final human release approval.**

The application is `Structured_Event_Schema_Validator_v1_0_2_VERIFIED_CANDIDATE.zip`. It includes executable main.py, modular source, rebuilt wheel/source distribution, preserved original tests and additional tests, both XML contracts, functional baselines/owner decisions, the 773-row matrix, complete audit logs, checked Lean models, report and per-file SHA-256 manifest. Extract that application ZIP to use the program.

The exact application ZIP passed a fresh-extraction replay: **410 passed; 0 failed, 0 errors, 0 skipped**. All 16 selected mutants were detected with a passing baseline and no invalid/time-out/harness-error outcomes. The 100,000-case independent-model campaign and 50,000-case boundary sweep passed. No confirmed unresolved defect remains in the verified finite scope. No universal zero-defect claim is made.

Application ZIP SHA-256: `f06ab83d0c56872460b30a402ce48662a06bb7cfdd3d73c10aebcc4919c02243`.

Read VERIFIED_RELEASE_REPORT.md and REQUIREMENTS_TRACEABILITY.csv/json. FINAL_ZIP_REPLAY.json/xml/txt supply the actual exact-artifact replay result; they are external to the application ZIP so its tested bytes remain unchanged. FINAL_ZIP_GATE.json shows the remaining human-governance blockers. SHA256SUMS.txt covers these delivery files; SHA256_MANIFEST.json covers the 492 files inside the application ZIP other than the manifest itself.

This verifies the owner-designated synthetic local validator. Live business connectors, organization-governed deployment, crash lease reclamation and universal security/correctness remain outside that baseline. Passing automation does not supply final human release authority: Verification XML P_SEC17_023 states “Passing automated gates does not override user-only release authority.” No human approval has been granted.

Reusable cloud install/start instructions were saved to the environment configuration draft. Review and save them in environment settings, then publish if desired. Saving a draft does not publish the environment or establish fresh-task restoration.
