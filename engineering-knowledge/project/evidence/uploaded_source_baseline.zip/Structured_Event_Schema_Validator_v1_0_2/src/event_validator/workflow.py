"""Deliberately local stub only; no outbound connector is implemented or enabled."""
from __future__ import annotations
from typing import Protocol
from .storage import SQLiteRepository

class Sink(Protocol):
    def deliver(self,message:dict)->bool:...

class LocalStubSink:
    def __init__(self):self.delivered=[]
    def deliver(self,message:dict)->bool:
        self.delivered.append(message['result_id']);return True

def dispatch_once(repo:SQLiteRepository,sink:Sink|None=None)->str:
    # None deliberately prevents external work. Only explicit passed sink executes.
    if sink is None:return 'DISABLED'
    claim=repo.claim()
    if not claim:return 'EMPTY'
    import json
    item_id,attempts,raw=claim
    try:
        ok=sink.deliver(json.loads(raw))
    except Exception:ok=False
    return repo.finish(item_id,bool(ok))
