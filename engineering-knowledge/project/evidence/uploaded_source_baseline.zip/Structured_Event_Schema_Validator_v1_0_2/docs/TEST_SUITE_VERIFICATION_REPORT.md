# Structured Event Schema Validator — Independent Test Suite Report

**Assessment date:** 2026-10-29  
**Artifact:** `test_suite.py` (standalone single-file pytest + optional Hypothesis verification suite)  
**Scope:** Testing artifact correction and independent checks of the original application.

## Tests executed

| Command | Result | Meaning |
|---|---|---|
| `python -m py_compile test_suite.py tests/property/test_properties.py` | PASS | Both Python test files parse/compile using Python 3.13.5 |
| `python -m pytest -q tests` | 19 passed, 1 skipped | Original tests still run; Hypothesis suite explicitly skipped because dependency unavailable |
| `python -m pytest -q test_suite.py -k 'not release_'` | 81 passed, 1 skipped, 10 deselected | Deterministic diagnostic baseline passed; release-blocking checks intentionally excluded; **not a release approval** |
| `python -m pytest -q test_suite.py` | **10 failed, 81 passed, 1 skipped** | Full release gate correctly FAILS on application defects and unexecuted Hypothesis |

Environment: CPython 3.13.5, pytest 9.0.2, Pydantic 2.13.5. Python 3.12 was **not** available for execution. `hypothesis` was absent; an attempted `pip install 'hypothesis>=6.100,<7'` failed due to blocked network/name resolution. No Hypothesis-generated examples or stateful traces were executed. PostgreSQL driver/server and Lean kernel proofs were not run.

## Test-harness corrections made

1. Created `test_suite.py` with 92 collected cases in this environment (10 release checks, 81 passing deterministic checks, one skipped dependency-check substitute); collection and assertion paths are executable.
2. Corrected `tests/property/test_properties.py` to import `RuleBasedStateMachine`, `rule`, and `invariant` from `hypothesis.stateful`, rather than the unsupported top-level `hypothesis` import.
3. When Hypothesis is unavailable, the old property module explicitly skips rather than preventing the entire repository test suite from collecting.
4. Added a *mandatory* Hypothesis dependency release test to `test_suite.py`; the full release gate cannot pass in the current runtime without actually installing the dependency.
5. Added a restricted-domain independent parser oracle; an explicit corrupted-output control demonstrates that the comparison detects an altered result.
6. Added valid/invalid golden fixtures, every event type, boundaries, strict Pydantic, timestamps, input limits, malformed matrices, stateful Hypothesis specification, SQLite transactions/idempotency, workflow quarantine, and subprocess CLI tests.
7. No known application failure has been suppressed using `xfail` or converted into a passing test.

## Distinct application defects confirmed by failing release checks

| Check(s) | Defect | Blocking effect |
|---|---|---|
| `test_release_serialization_must_preserve_all_event_fields[0..4]` | Accepted subclass-specific fields vanish from `ValidationResult.canonical()` for all 5 event models; `record: Common` is declared too narrowly for Pydantic's serializer | JSONL/SQLite result payloads lose business fields |
| `test_release_invalid_unicode_must_not_crash[\ud800,\udfff]` | UTF-8 digest/size calculations raise `UnicodeEncodeError` on unpaired surrogates | Invalid input causes an uncaught exception instead of typed rejection |
| `test_release_cli_rejected_inputs_use_collision_safe_identity` | Rejected events with default `--batch-ref` can reuse `(tenant_id,event_ref,matrix)` across CLI executions; second distinct invalid event receives `ERROR:IdempotencyConflict` | Valid rejection results are not durably stored |
| `test_release_malformed_field_type_matrix_is_typed_config_error` | List-valued `field_types` escapes `load_matrix()` with `AttributeError`, rather than `ConfigError` | Malformed external config can bypass controlled error response |
| `test_release_hypothesis_dependency_must_be_installed` | Hypothesis not installed in test runtime | Property/stateful fuzzing remains unexecuted |

**Release judgment:** NOT APPROVED. The test harness itself is ready for inclusion in the verification pipeline; the application and full Hypothesis execution remain open.

## Reproduce

```bash
# Run in package root, after installing pytest and pydantic
python -m pytest -q test_suite.py
# Diagnostic-only subset (excludes critical release checks; NOT a release decision)
python -m pytest -q test_suite.py -k 'not release_'
# On a networked Python 3.12+ environment, first install Hypothesis:
python -m pip install -e '.[test]'
python -m pytest -q test_suite.py
python -m pytest -q tests
```

Use a clean venv; never mark a missing dependency as a passing verification result. Run against a corrected application without weakening assertions. Document full outcomes and preserve exact version/payload provenance.
