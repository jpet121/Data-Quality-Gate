# Verification evidence — repaired release (2026-10-29)

Environment: Python 3.13.5, Pydantic 2.13.5, pytest 9.0.2, SQLite stdlib. No Python 3.12 runtime, Hypothesis distribution, or PostgreSQL server was present.

## Executed checks

`pytest -q`: **57 passed, 1 skipped**. The Hypothesis module was skipped because the optional dependency is not installed; its tests were NOT executed.

- Regression and fault-injection tests include actual SQLite rollback injection, error exit code checking, invalid Unicode, schema drift, event identity guard, accepted business fields persisted, and isolated standalone CLI parity.
- Deterministic random inputs: 16,500 cases with fixed seeds; tested for exceptions and consistent repeat results.
- Standalone `main.py` is assembled from the tested modules with a reproducible generator; executed with `python -I` from another working directory and independently migrated SQLite.
- Python 3.12 grammar was parsed using `ast.parse(..., feature_version=(3,12))` on Python 3.13, not tested under a Python 3.12 interpreter.

## Local synthetic benchmark without SQLite

`python benchmarks/benchmark.py --count 1000 --seed 1701`

```json
{"accepted": 896, "count": 1000, "cpu_seconds": 0.27828, "db_counts": null, "db_enabled": false, "events_per_sec": 3593.4, "p50_ms": 0.253, "p95_ms": 0.396, "peak_tracemalloc_bytes": 203800, "rejected": 104, "seconds": 0.27829, "seed": 1701}
```

## Local synthetic benchmark with SQLite

`python benchmarks/benchmark.py --count 300 --seed 1701 --db`

```json
{"accepted": 265, "count": 300, "cpu_seconds": 0.30338, "db_counts": {"event_ingestion": 300, "normalization_audit": 859, "validation_error": 35, "validation_result": 300, "workflow_outbox": 300}, "db_enabled": true, "events_per_sec": 435.3, "p50_ms": 2.223, "p95_ms": 2.864, "peak_tracemalloc_bytes": 138191, "rejected": 35, "seconds": 0.68923, "seed": 1701}
```

These numbers are environment-specific observations, not a performance guarantee. For unverified production features, open acceptance limits, and source-contract availability, see `REPAIR_RELEASE_REPORT.md`.
