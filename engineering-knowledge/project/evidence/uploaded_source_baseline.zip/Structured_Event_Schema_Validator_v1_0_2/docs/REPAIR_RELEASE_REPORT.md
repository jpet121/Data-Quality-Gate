# Structured Event Schema Validator — repaired release verification

**Build date:** 2026-10-29. **Status:** release candidate validated for the local SQLite demonstration. **Not certified for production integrations or PostgreSQL.**

## Original defects reproduced and corrected

1. **Lossy accepted record serialization:** Pydantic v2's base-class-typed field omitted subclass-specific business fields when serializing accepted outcomes. `SerializeAsAny[Common]` preserves every validated event-specific field in the canonical output and persisted payload. Confirmed against all five event types.
2. **Malformed Unicode crash:** original strict UTF-8 encoding raised `UnicodeEncodeError` on lone surrogate input. Ingestion now deterministically rejects it as `INPUT_LIMIT/invalid_unicode`; a stable fingerprint is computed using surrogate-pass encoding solely for the rejected input hash.
3. **False-success CLI exit:** SQLite persistence errors previously produced `storage_state=ERROR:...` with exit status 0. They now cause exit status 3, even when some outputs were processed; errors are sanitized. File read problems return status 2.
4. **Non-standalone main.py:** the original 94-byte file imported the application from an external `src` tree. The generated `main.py` embeds the tested implementation and the SQLite migration; it executes without the source tree when Pydantic v2 is installed. The build is reproducible via `python scripts/build_standalone.py` and parity is tested.
5. **Untrusted configuration drift:** registry, required fields, event type, and declared decoding kinds are cross-checked against registered Pydantic models at matrix load time. Malformed matrix shapes fail as `ConfigError` rather than raising uncontrolled errors.
6. **Cross-tenant identity mismatch:** repositories reject attempts to persist an accepted event under a tenant ID or event reference inconsistent with its validated model.
7. **Privacy/hardening:** unsupported event labels are not echoed in canonical rejection outputs. RFC3339 offsets are bounded by ±14:00 with only the zero-minute value valid at ±14 hours.
8. **Optional PostgreSQL transaction handling:** connection uses autocommit mode with explicit `conn.transaction()` scopes to avoid implicit-transaction commit ambiguity. **This change was not integration-tested against PostgreSQL.**

## Executed evidence

- `pytest -q`: **57 passed, 1 skipped**. The skipped module requires the unavailable Hypothesis dependency; no claim of executed Hypothesis testing is made.
- Deterministic fuzz: 6,000 general random Unicode strings, 5,000 alternate lexer strings, 3,500 structured mutations, and 2,000 additional valid-event mutations (16,500 generated cases across four test functions); repeated validation equality checked.
- Independent parser comparison on constrained unquoted token permutations.
- Verified regression scenarios: semantic Pydantic records preserved, malformed Unicode, unexpected input file, SQLite initialization failure, SQLite persistence failure, atomic rollback on injected outbox failure, tenant identity mismatch, schema registry mismatch, syntax and alias errors, and canonical CLI replay.
- `main.py` independently executed under isolated Python `-I` from an external working directory, including SQLite migration and replay; output parity with package API verified.
- Python 3.12 grammar parsing via `ast.parse(..., feature_version=(3,12))` passed on Python 3.13.5. **This is not Python 3.12 runtime testing.**
- Synthetic benchmarks were executed under Python 3.13.5, Pydantic 2.13.5, pytest 9.0.2. The results are workload- and machine-specific; no production throughput claims.

## Remaining verification limits

- **Hypothesis property suite is supplied but not executed:** offline environment could not install the optional dependency. Install `pip install -e '.[test]'` in a connected environment and execute `pytest -q` to exercise it.
- **PostgreSQL adapter remains unverified against a running PostgreSQL server**; migrations are a reference blueprint only. Do not treat its transaction, concurrency, or delivery semantics as production-certified.
- **No Python 3.12 interpreter** was available. Python 3.12-compatible syntax was checked, but actual runtime certification must occur on Python 3.12.
- Outbox delivery remains a synthetic disabled-by-default demonstration. Crash-recoverable leases, downstream delivery deduplication and external connector authorization are not implemented as production capability.
- The provided `Development & Software Architecture.xml` is a generic downstream execution contract that itself says the validator's *actual source XML* must be provided separately. The original validator-specific contract was not available in the input ZIP. Fidelity was checked against the shipped README, matrix, tests, and acceptance documentation, not a missing upstream feature-by-feature XML specification.

## Reproduction

```bash
python -m pip install 'pydantic>=2.10,<3' 'pytest>=8,<10'
python main.py --matrix examples/matrix_v1.json --input examples/replay.jsonl --db demo.sqlite
pytest -q
# To run the supplied, separately gated Hypothesis property suite:
python -m pip install 'hypothesis>=6.100,<7'
pytest -q
python scripts/build_standalone.py
```

`main.py` needs Pydantic v2 and supplied matrix/input data, but does not import the external package or require the migration SQL file at runtime.

## Architectural alignment

- **Percival & Gregory, *Architecture Patterns with Python*:** domain/validation boundaries, explicit repository and atomic transaction use, and isolated input adapters.
- **Martin, *Clean Architecture*:** dependency direction and separation of parsing/validation rules from CLI and persistence concerns.
- **Gamma et al., *Design Patterns*:** bounded registries/adapters used where they solve actual interface boundaries; avoid speculative pattern proliferation.
- **Ramalho, *Fluent Python*:** frozen data models, predictable types, strict text/Unicode semantics, and idiomatic domain serialization.
- **Viafore, *Robust Python*:** explicit typing, fail-closed invalid inputs, and regression testing of error paths.

These alignments express the relevant design principles; they are not evidence that every book example or architecture pattern is mandatory.
