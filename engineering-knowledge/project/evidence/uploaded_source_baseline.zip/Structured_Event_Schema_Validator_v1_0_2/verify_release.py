"""Verify SHA-256 for all tracked files in this candidate directory."""
from __future__ import annotations
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def main()->int:
    manifest=json.loads((ROOT/'SHA256_MANIFEST.json').read_text(encoding='utf-8'))
    mismatches=[]
    for rel, expected in manifest['files'].items():
        path=ROOT/rel
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
            mismatches.append(rel)
    if mismatches:
        print('FAILED:',','.join(mismatches));return 1
    print(f"PASS: {len(manifest['files'])} files match SHA-256 manifest")
    return 0

if __name__=='__main__':raise SystemExit(main())
