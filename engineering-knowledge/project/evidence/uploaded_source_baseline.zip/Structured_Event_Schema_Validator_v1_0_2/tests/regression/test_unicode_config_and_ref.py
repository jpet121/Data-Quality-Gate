"""Surrogate ingress must not reach JSON serialization via metadata fields."""
from __future__ import annotations
import json
from pathlib import Path
import pytest
from event_validator import load_matrix, validate
from event_validator.matrix import ConfigError

ROOT = Path(__file__).resolve().parents[2]

@pytest.mark.parametrize('target', ['version','schema_id','schema_version'])
@pytest.mark.parametrize('bad_unicode', ['\ud800','\udfff','prefix\ud800suffix'])
def test_metadata_with_invalid_unicode_is_rejected_as_config_error(tmp_path,target,bad_unicode):
    matrix=json.loads((ROOT/'examples/matrix_v1.json').read_text())
    if target=='version':matrix['version']=bad_unicode
    else:matrix['events'][0][target]=bad_unicode
    path=tmp_path/'bad_matrix.json';path.write_text(json.dumps(matrix),encoding='utf-8')
    with pytest.raises(ConfigError):load_matrix(path)

@pytest.mark.parametrize('invalid_ref', ['\ud800','batch\udfff',None,42])
def test_invalid_input_ref_is_controlled_api_error(cfg,valid,invalid_ref):
    with pytest.raises(ValueError,match='invalid_input_ref'):
        validate(valid[0],invalid_ref,cfg)
