"""Independent regression checks for stable, collision-safe CLI event identities."""
from __future__ import annotations
import json
import sqlite3
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def invoke(input_path: Path, database: Path):
    result = subprocess.run(
        [sys.executable, '-I', str(ROOT / 'main.py'), '--matrix',
         str(ROOT / 'examples/matrix_v1.json'), '--input', str(input_path),
         '--db', str(database)],
        cwd=input_path.parent, capture_output=True, text=True, check=False,
        timeout=20,
    )
    return result, json.loads(result.stdout.strip())


def test_rejected_unchanged_duplicate_and_changed_input_do_not_collide(tmp_path):
    raw = [json.loads(line)['raw'] for line in (ROOT/'examples/invalid.jsonl').read_text().splitlines()]
    paths = []
    for i in (0, 1):
        path = tmp_path / f'bad{i}.jsonl'
        path.write_text(json.dumps({'raw': raw[i]}) + '\n', encoding='utf-8')
        paths.append(path)
    db=tmp_path/'identity.sqlite'
    first, a = invoke(paths[0],db)
    repeat, b = invoke(paths[0],db)
    changed, c = invoke(paths[1],db)
    assert [r.returncode for r in (first,repeat,changed)] == [0,0,0]
    assert [r['storage_state'] for r in (a,b,c)] == ['CREATED','DUPLICATE','CREATED']
    with sqlite3.connect(db) as con:
        rows = con.execute('SELECT event_ref,input_hash FROM event_ingestion ORDER BY input_hash').fetchall()
    assert len(rows) == 2
    assert len({event_ref for event_ref,_ in rows}) == 2
    assert all(event_ref.endswith(sha) for event_ref,sha in rows)


def test_accepted_idempotency_remains_event_id_based(tmp_path):
    rows=[json.loads(line)['raw'] for line in (ROOT/'examples/valid.jsonl').read_text().splitlines()]
    p=tmp_path/'accepted.jsonl'; db=tmp_path/'accepted.sqlite'
    p.write_text(json.dumps({'raw': rows[1]})+'\n')
    a,x=invoke(p,db)
    b,y=invoke(p,db)
    assert [a.returncode,b.returncode] == [0,0]
    assert (x['storage_state'],y['storage_state']) == ('CREATED','DUPLICATE')
    p.write_text(json.dumps({'raw': rows[1].replace('PAY-FAKE-55','PAY-FAKE-99')})+'\n')
    c,z=invoke(p,db)
    assert c.returncode == 3
    assert z['storage_state'] == 'ERROR:IdempotencyConflict'
    with sqlite3.connect(db) as con:
        assert con.execute('SELECT count(*) FROM event_ingestion').fetchone()[0] == 1
