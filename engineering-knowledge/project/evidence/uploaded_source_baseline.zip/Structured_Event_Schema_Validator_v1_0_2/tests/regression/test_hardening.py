"""Fault injection, deterministic randomized checks, and standalone release parity."""
from __future__ import annotations

import json
import random
import sqlite3
import subprocess
import sys
from pathlib import Path

import pytest

from event_validator import load_matrix, validate
from event_validator.cli import main as cli_main
from event_validator.matrix import ConfigError
from event_validator.storage import SQLiteRepository

ROOT = Path(__file__).resolve().parents[2]
MATRIX = ROOT / 'examples' / 'matrix_v1.json'


def test_surrogate_unicode_rejected_not_crashed(cfg):
    for bad in ('\ud800', '\udfff', 'event=\ud800', 'event="\udfff"'):
        outcome = validate(bad, 'surrogate', cfg)
        assert outcome.status == 'REJECTED'
        assert outcome.errors[0].code == 'invalid_unicode'
        assert outcome.canonical() == validate(bad, 'surrogate', cfg).canonical()
        assert '\\ud800' not in outcome.canonical()


def test_unsupported_type_does_not_echo_untrusted_event_label(cfg):
    label = 'VERY-SECRET-CUSTOMER-REFERENCE'
    output = validate(f'event={label}', 'secret', cfg).canonical()
    assert label not in output
    assert 'event_type' not in json.loads(output)


def test_extreme_nested_json_rejects_without_exception(cfg,valid):
    header = valid[0].split(' | lines_json=')[0]
    deep = '[' * 1500 + '0' + ']' * 1500
    result = validate(header + ' | lines_json="' + deep + '"', 'deep', cfg)
    assert result.status == 'REJECTED'
    assert result.errors[0].code == 'lexical_type_error'


def test_offset_outside_standard_rfc3339_rejected(cfg, valid):
    assert validate(valid[1].replace('-05:00', '+14:00'), 'ref', cfg).status == 'ACCEPTED'
    assert validate(valid[1].replace('-05:00', '+14:01'), 'ref', cfg).status == 'REJECTED'
    assert validate(valid[1].replace('-05:00', '-14:01'), 'ref', cfg).status == 'REJECTED'


@pytest.mark.parametrize('change,value', [
    ('required', ['event_type']),
    ('optional', ['tenant_id']),
    ('field_type', 'str'),
    ('event_type', 'ORDER_CANCELLED'),
])
def test_matrix_must_match_registered_model(change, value, tmp_path):
    obj = json.loads(MATRIX.read_text())
    spec = obj['events'][0]
    if change == 'field_type':
        spec['field_types']['gross_amount'] = value
    else:
        spec[change] = value
    bad = tmp_path / 'bad.json'
    bad.write_text(json.dumps(obj))
    with pytest.raises(ConfigError):
        load_matrix(bad)


def test_storage_errors_result_in_nonzero_exit(monkeypatch, tmp_path, capsys, valid):
    path = tmp_path / 'input.jsonl'
    path.write_text(json.dumps({'raw': valid[0]}) + '\n')

    def explode(*args, **kwargs):
        raise RuntimeError('sensitive internal error')

    monkeypatch.setattr(SQLiteRepository, 'persist', explode)
    dbpath = tmp_path / 'db.sqlite'
    exit_code = cli_main(['--matrix', str(MATRIX), '--input', str(path), '--db', str(dbpath)])
    output = capsys.readouterr()
    assert exit_code == 3
    row = json.loads(output.out)
    assert row['storage_state'] == 'ERROR:RuntimeError'
    assert 'sensitive internal error' not in output.out + output.err


def test_database_initialization_failure_nonzero(tmp_path, capsys):
    bad_db = tmp_path / 'nonexistent_directory' / 'db.sqlite'
    exit_code = cli_main(['--matrix', str(MATRIX), '--db', str(bad_db)])
    assert exit_code == 3
    err = json.loads(capsys.readouterr().err)
    assert err['status'] == 'STORAGE_ERROR'


def test_unreadable_input_nonzero(tmp_path, capsys):
    exit_code = cli_main(['--matrix', str(MATRIX), '--input', str(tmp_path/'not_found.jsonl')])
    assert exit_code == 2
    err = json.loads(capsys.readouterr().err)
    assert err['status'] == 'INPUT_ERROR'


def test_standalone_cli_without_local_package(tmp_path):
    inputs = ROOT / 'examples' / 'replay.jsonl'
    db = tmp_path / 'standalone.sqlite'
    run = subprocess.run(
        [sys.executable, '-I', str(ROOT/'main.py'), '--matrix', str(MATRIX),
         '--input', str(inputs), '--db', str(db)],
        cwd=tmp_path, capture_output=True, text=True, timeout=20, check=False,
    )
    assert run.returncode == 0, run.stderr
    results = [json.loads(line) for line in run.stdout.splitlines()]
    assert [r['status'] for r in results] == ['ACCEPTED','REJECTED','ACCEPTED']
    assert all(r['storage_state'] == 'CREATED' for r in results)
    with sqlite3.connect(db) as c:
        assert c.execute('SELECT count(*) FROM workflow_outbox').fetchone()[0] == 3
    from event_validator import validate_many
    expected = list(validate_many(
        (json.loads(line)['raw'] for line in inputs.read_text().splitlines()), 'batch',
        load_matrix(MATRIX)))
    assert [{k:v for k,v in row.items() if k!='storage_state'} for row in results] == [
        json.loads(x.canonical()) for x in expected
    ]


def test_seeded_unstructured_lexer_stress(cfg):
    rng = random.Random(20261029)
    alphabet = 'aZ09_=|\\"\n\t$#é中\ud800\udfff'
    for i in range(5000):
        value = ''.join(rng.choices(alphabet, k=rng.randrange(180)))
        result = validate(value, f'fuzz/{i}', cfg)
        assert result.status in ('ACCEPTED', 'REJECTED')
        assert result.canonical() == validate(value, f'fuzz/{i}', cfg).canonical()


def test_seeded_structured_mutation_stress(cfg,valid):
    rng = random.Random(19)
    for i in range(3500):
        base = rng.choice(valid)
        op = rng.randrange(5)
        if op == 0:
            chunks = base.split(' | ')
            rng.shuffle(chunks)
            mutated = ' | '.join(chunks)
        elif op == 1:
            mutated = base + ' | ' + rng.choice(['junk=bad','event=ORDER_CREATED','source=ERP'])
        elif op == 2:
            pos = rng.randrange(len(base))
            mutated = base[:pos] + rng.choice('"\\|=\ud800') + base[pos:]
        elif op == 3:
            mutated = base[:rng.randrange(len(base))]
        else:
            mutated = base.replace('2026-10-29', 'not-a-date',1)
        result = validate(mutated, f'mutation/{i}', cfg)
        assert result.status in ('ACCEPTED', 'REJECTED')
        assert result.canonical() == validate(mutated, f'mutation/{i}', cfg).canonical()
