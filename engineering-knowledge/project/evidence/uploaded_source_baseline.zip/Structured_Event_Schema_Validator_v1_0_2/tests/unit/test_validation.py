from datetime import datetime
from decimal import Decimal
import json,random
from pathlib import Path
import pytest
from pydantic import ValidationError
from event_validator import validate,validate_many,Failure,load_matrix
from event_validator.models import OrderCreated
from event_validator.parser import tokenize,ParseFault
from event_validator.matrix import ConfigError

def test_golden_valid(cfg,valid):
    assert len(valid)==5
    assert all(validate(x,'test',cfg).status=='ACCEPTED' for x in valid)

def test_golden_invalid(cfg,invalid):
    got=[validate(x,'test',cfg) for x in invalid]
    assert len(got)==9 and all(x.status=='REJECTED' for x in got)
    assert [r.failure_category for r in got]==[
        Failure.SCHEMA_VIOLATION,Failure.PARSE_ERROR,Failure.SCHEMA_VIOLATION,
        Failure.SCHEMA_VIOLATION,Failure.SCHEMA_VIOLATION,Failure.SCHEMA_VIOLATION,
        Failure.UNSUPPORTED_EVENT,Failure.PARSE_ERROR,Failure.PARSE_ERROR]

def test_batch_isolation(cfg,valid,invalid):
    actual=list(validate_many([valid[0],invalid[0],valid[1]],'B',cfg))
    assert [x.status for x in actual]==['ACCEPTED','REJECTED','ACCEPTED']
    assert [x.index for x in actual]==[0,1,2]

def test_determinism(cfg,valid):
    assert validate(valid[0],'i',cfg).canonical()==validate(valid[0],'i',cfg).canonical()
    fields=valid[1].split(' | ')
    perm=' | '.join(reversed(fields))
    a=validate(valid[1],'i',cfg);b=validate(perm,'i',cfg)
    assert a.record==b.record and a.status==b.status

def test_no_sensitive_diagnostics(cfg,invalid):
    for raw in invalid:
        result=validate(raw+' | payment_ref=SECRET-CARD-999','i',cfg)
        assert 'SECRET-CARD-999' not in ''.join(x.message for x in result.errors)
        assert 'CUST-FAKE-11' not in ''.join(x.message for x in result.errors)

def test_duplicate_even_identical(cfg,valid):
    assert validate(valid[1]+' | currency=USD','i',cfg).failure_category==Failure.PARSE_ERROR

def test_unsupported_free_prose(cfg):
    assert validate('make it an order','i',cfg).failure_category==Failure.PARSE_ERROR

def test_strict_model_without_lexer():
    data=dict(event_type='ORDER_CREATED',event_id='EVT-A',tenant_id='TEN-A',order_id='ORD-A',source='ERP',occurred_at=datetime.now().astimezone(),customer_ref='C-A',gross_amount='12.00',currency='USD')
    with pytest.raises(ValidationError):OrderCreated.model_validate(data,strict=True)
    data['gross_amount']=Decimal('12.00');data['occurred_at']=datetime(2026,10,29)
    with pytest.raises(ValidationError):OrderCreated.model_validate(data,strict=True)

def test_nested_reject_duplicate_json_key(cfg,valid):
    start=valid[0].split(' | lines_json=')[0]
    nested='[{"sku_code":"SKU-A","quantity":2,"quantity":2,"unit_price":"12.50"}]'
    value=nested.replace('"',r'\"')
    assert validate(start+' | lines_json="'+value+'"','i',cfg).status=='REJECTED'

def test_parser_quote_and_escape():
    assert tokenize('a="v|x" | b="say \\"hi\\""',10)==[('a','v|x'),('b','say "hi"')]
    for s in ['a="unclosed','a=x |','a=x | a=x','a=x extra','a=\\x']:
        with pytest.raises(ParseFault):tokenize(s,10)

def test_input_bounds(cfg):
    assert validate('x'*6000,'i',cfg).failure_category==Failure.INPUT_LIMIT
    assert validate(None,'i',cfg).failure_category==Failure.INPUT_LIMIT
    assert validate('x=a | '*40,'i',cfg).failure_category in (Failure.PARSE_ERROR,Failure.INPUT_LIMIT)

def test_config_reject_unknown_registry(tmp_path):
    p=Path(__file__).resolve().parents[2]/'examples/matrix_v1.json'
    cfg=json.loads(p.read_text());cfg['events'][0]['registry_key']='arbitrary.module'
    target=tmp_path/'evil.json';target.write_text(json.dumps(cfg))
    with pytest.raises(ConfigError):load_matrix(target)

def test_ambiguity(tmp_path,cfg,valid):
    p=Path(__file__).resolve().parents[2]/'examples/matrix_v1.json'
    obj=json.loads(p.read_text())
    new=dict(obj['events'][0]);new['schema_id']='ORDER_CREATED_SHADOW'
    obj['events'].append(new)
    target=tmp_path/'ambiguous.json';target.write_text(json.dumps(obj))
    c=load_matrix(target)
    assert validate(valid[0],'i',c).failure_category==Failure.AMBIGUOUS_EVENT

def test_timezone_offsets(cfg,valid):
    assert validate(valid[1].replace('-05:00','+14:00'),'i',cfg).status=='ACCEPTED'
    assert validate(valid[1].replace('-05:00','+15:00'),'i',cfg).status=='REJECTED'
