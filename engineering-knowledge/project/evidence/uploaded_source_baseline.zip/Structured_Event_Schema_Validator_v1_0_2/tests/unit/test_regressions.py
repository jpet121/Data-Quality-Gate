"""Regression tests against observed defects and hostile/untrusted inputs."""
from __future__ import annotations
import json
import random
import sqlite3
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

from event_validator import load_matrix, validate, Failure
from event_validator.cli import main as cli_main
from event_validator.matrix import ConfigError
from event_validator.storage import SQLiteRepository

ROOT = Path(__file__).resolve().parents[2]


def test_accepted_serialization_preserves_every_event_field(cfg, valid):
    for raw in valid:
        result = validate(raw, 'golden', cfg)
        assert result.status == 'ACCEPTED'
        encoded = json.loads(result.canonical())
        assert encoded['record'] == json.loads(result.record.model_dump_json())
        assert 'event_id' in encoded['record']
    record = json.loads(validate(valid[0], 'golden', cfg).canonical())['record']
    assert record['gross_amount'] == '25.00'
    assert record['customer_ref'] == 'CUST-FAKE-11'
    assert record['lines_json'][0]['unit_price'] == '12.50'


@pytest.mark.parametrize('raw', ['\ud800', 'event=ORDER_CREATED | notes=\udfff', '\ud800' * 2000])
def test_unpaired_surrogate_rejected_without_crash(cfg, raw):
    x = validate(raw, 'malformed', cfg)
    assert x.failure_category is Failure.INPUT_LIMIT
    assert x.errors[0].code == 'invalid_unicode'
    assert x.canonical() == validate(raw, 'malformed', cfg).canonical()


def test_cli_returns_nonzero_on_persistence_failure(tmp_path, capsys):
    infile = ROOT / 'examples/replay.jsonl'
    class FailingRepo:
        def __init__(self, path): pass
        def migrate(self): pass
        def persist(self, *args, **kwargs): raise RuntimeError('synthetic disk failure')
        def close(self): pass
    with patch('event_validator.storage.SQLiteRepository', FailingRepo):
        exit_code = cli_main(['--matrix', str(ROOT / 'examples/matrix_v1.json'),
                              '--input', str(infile), '--db', str(tmp_path/'db.sqlite')])
    out = capsys.readouterr().out
    assert exit_code == 3
    assert len(out.splitlines()) == 3
    assert all('"storage_state":"ERROR:RuntimeError"' in line for line in out.splitlines())


def test_cli_invalid_input_file_returns_nonzero(capsys):
    code=cli_main(['--matrix',str(ROOT/'examples/matrix_v1.json'), '--input','/does/not/exist/invalid.jsonl'])
    assert code == 2
    assert 'INPUT_ERROR' in capsys.readouterr().err


def test_cli_invalid_database_path_returns_nonzero(capsys, tmp_path):
    code=cli_main(['--matrix',str(ROOT/'examples/matrix_v1.json'),
                   '--input',str(ROOT/'examples/replay.jsonl'), '--db',str(tmp_path/'no_such_folder'/'db.sqlite')])
    assert code == 3
    assert 'STORAGE_ERROR' in capsys.readouterr().err


def test_storage_transaction_rollback_on_outbox_insert_failure(tmp_path, cfg, valid):
    repo = SQLiteRepository(tmp_path/'test.sqlite')
    try:
        repo.migrate()
        repo.connection.execute('''CREATE TRIGGER abort_outbox BEFORE INSERT ON workflow_outbox
                                    BEGIN SELECT RAISE(ABORT, 'fault injected'); END''')
        with pytest.raises(sqlite3.IntegrityError):
            repo.persist(validate(valid[0], 'r', cfg), 'TEN-ACME', 'EVT-001')
        assert all(v == 0 for v in repo.counts().values())
        assert repo.connection.execute('SELECT count(*) FROM matrix_version').fetchone()[0] == 0
    finally:
        repo.close()


@pytest.mark.parametrize('field,new_kind', [('quantity','str'),('gross_amount','integer'),('occurred_at','str')])
def test_config_rejects_type_punning(tmp_path, field, new_kind):
    obj=json.loads((ROOT/'examples/matrix_v1.json').read_text())
    for spec in obj['events']:
        if field in spec['field_types']:
            spec['field_types'][field]=new_kind
    target=tmp_path/'matrix.json';target.write_text(json.dumps(obj))
    with pytest.raises(ConfigError, match='field_kind_mismatch'):load_matrix(target)


def test_config_rejects_optional_required_mismatch(tmp_path):
    obj=json.loads((ROOT/'examples/matrix_v1.json').read_text())
    obj['events'][0]['required'].remove('gross_amount')
    obj['events'][0]['optional'].append('gross_amount')
    target=tmp_path/'matrix.json';target.write_text(json.dumps(obj))
    with pytest.raises(ConfigError, match='required_fields_mismatch'):load_matrix(target)


def test_config_rejects_event_registry_mismatch(tmp_path):
    obj=json.loads((ROOT/'examples/matrix_v1.json').read_text())
    obj['events'][0]['event_type']='PAYMENT_AUTHORIZED'
    obj['events'][0]['matcher']['equals']='PAYMENT_AUTHORIZED'
    target=tmp_path/'matrix.json';target.write_text(json.dumps(obj))
    with pytest.raises(ConfigError, match='event_registry_mismatch'):load_matrix(target)


def test_deterministic_random_fuzz_no_crash(cfg):
    rng=random.Random(20261029)
    alphabet='abcdefghijklmnopqrstuvwxyz\u2028\u0000\u2603|=\\"\ud800\udfff\U0001f4e6 '
    for i in range(6000):
        value=''.join(rng.choices(alphabet,k=rng.randrange(0,100)))
        result=validate(value, f'case/{i}',cfg)
        assert result.status in ('ACCEPTED','REJECTED')
        assert json.loads(result.canonical())['input_ref'] == f'case/{i}'
        assert result.canonical() == validate(value,f'case/{i}',cfg).canonical()


def test_standalone_script_matches_package_replay():
    command=[sys.executable,str(ROOT/'main.py'),'--matrix',str(ROOT/'examples/matrix_v1.json'),
             '--input',str(ROOT/'examples/replay.jsonl')]
    res=subprocess.run(command,capture_output=True,text=True,cwd='/tmp',check=False)
    assert res.returncode == 0, res.stderr
    assert len(res.stdout.splitlines()) == 3
    from event_validator.core import validate_many
    raw=[json.loads(x)['raw'] for x in (ROOT/'examples/replay.jsonl').read_text().splitlines()]
    cfg=load_matrix(ROOT/'examples/matrix_v1.json')
    expected=[json.loads(r.canonical()) for r in validate_many(raw,'batch',cfg)]
    assert [json.loads(x) for x in res.stdout.splitlines()] == expected


def test_standalone_sqlite_migrates_when_run_outside_checkout(tmp_path):
    command=[sys.executable,str(ROOT/'main.py'),'--matrix',str(ROOT/'examples/matrix_v1.json'),
             '--input',str(ROOT/'examples/replay.jsonl'),'--db',str(tmp_path/'events.sqlite')]
    res=subprocess.run(command,capture_output=True,text=True,cwd='/tmp',check=False)
    assert res.returncode == 0,res.stderr
    assert [json.loads(x)['storage_state'] for x in res.stdout.splitlines()] == ['CREATED']*3
    with sqlite3.connect(tmp_path/'events.sqlite') as c:
        assert c.execute('SELECT count(*) FROM event_ingestion').fetchone()[0] == 3


@pytest.mark.parametrize('bad_value', [[], 'str', 42, None])
def test_matrix_wrong_field_types_shape_rejects_cleanly(tmp_path, bad_value):
    obj=json.loads((ROOT/'examples/matrix_v1.json').read_text())
    obj['events'][0]['field_types']=bad_value
    path=tmp_path/'bad.json';path.write_text(json.dumps(obj))
    with pytest.raises(ConfigError):load_matrix(path)


def test_matrix_wrong_schema_id_shape_rejects_cleanly(tmp_path):
    obj=json.loads((ROOT/'examples/matrix_v1.json').read_text())
    obj['events'][0]['schema_id']=['nested','id']
    path=tmp_path/'bad.json';path.write_text(json.dumps(obj))
    with pytest.raises(ConfigError):load_matrix(path)


def test_storage_cannot_persist_event_under_other_tenant_or_event_id(tmp_path, cfg, valid):
    repo=SQLiteRepository(tmp_path/'isolated.sqlite')
    try:
        repo.migrate()
        result=validate(valid[0],'r',cfg)
        with pytest.raises(ValueError, match='ingestion_identity_mismatch'):
            repo.persist(result,'TEN-OTHER','EVT-001')
        with pytest.raises(ValueError, match='ingestion_identity_mismatch'):
            repo.persist(result,'TEN-ACME','EVT-OTHER')
        assert all(x == 0 for x in repo.counts().values())
    finally:
        repo.close()


def test_valid_event_mutations_are_total_and_deterministic(cfg,valid):
    rng=random.Random(1701)
    edits='abcdefghijklmnopqrstuvwxyz0123456789|=\\"\ud800\u2603'
    for i in range(2000):
        src=rng.choice(valid)
        mode=i % 4
        parts=src.split(' | ')
        if mode==0:
            rng.shuffle(parts)
            sample=' | '.join(parts)
        elif mode==1:
            idx=rng.randrange(len(src)+1)
            sample=src[:idx]+rng.choice(edits)+src[idx:]
        elif mode==2:
            sample=' | '.join(item for j,item in enumerate(parts) if j!=rng.randrange(len(parts)))
        else:
            sample=src+' | '+rng.choice(parts)
        res=validate(sample,f'mutation/{i}',cfg)
        assert res.status in ('ACCEPTED','REJECTED')
        assert res.canonical()==validate(sample,f'mutation/{i}',cfg).canonical()
