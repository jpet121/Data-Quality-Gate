# Corrected verification test file — Structured Event Schema Validator

**Primary deliverable:** `test_suite.py`, placed at the application package root beside `src/`, `main.py`, and `examples/`.

The application source code was not changed. This delivery corrects the old Hypothesis test import, adds a self-contained high-assurance-oriented verification suite, and preserves identified application failures as failing release checks.

## Commands

```bash
python -m pip install -e '.[test]'
python -m pytest -q test_suite.py
python -m pytest -q tests
```

For inspection only, not certification:

```bash
python -m pytest -q test_suite.py -k 'not release_'
```

If Hypothesis is absent, its tests do not run. The full suite includes a mandatory release test that fails while it is missing. On the review environment, the diagnostic profile yielded 81 passed / 1 skipped / 10 deselected, while the full suite failed on 9 application defect assertions and 1 missing-dependency assertion. See `docs/TEST_SUITE_VERIFICATION_REPORT.md`.

## Files changed / added

- `test_suite.py` — new independent regression, differential, property/stateful and release tests.
- `tests/property/test_properties.py` — repaired Hypothesis import plus explicit dependency-skip handling.
- `TEST_SUITE_README.md`, `docs/TEST_SUITE_VERIFICATION_REPORT.md`, `docs/TEST_SUITE_COVERAGE.md` — run instructions, actual evidence and claim mapping.
- `SHA256_MANIFEST.json` — rebuilt checksum manifest after test-only changes.

**IMPORTANT:** A nonzero pytest exit code is the correct result when the application violates a stated contract. Do not change expectations solely to obtain a green status.
